# Treasure Box Braille (TBB) System - Created by SDP-16

This version of the TBB System has been created by group 16 in EECS 2311.

The Treasure Box Braille (TBB) System is an application whose purpose is to assist visually impaired
students to learn the written language of Braille. The TBB runs on Scenario files which are automated
lessons interactive lessons created by instructors for their students to use. Through our software
application instructors will have the ability to create, edit and run scenario files. Visually impaired users
will also be able to make use of screen readers in order to perform UI functions.

Authors: Sanjay Paraboo, Damanveer Bharaj, Pengyuan Guo
