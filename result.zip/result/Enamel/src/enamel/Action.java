package enamel;

public abstract class Action {

	public abstract boolean build(ScenarioCreatorManager sm);
	
	
}
