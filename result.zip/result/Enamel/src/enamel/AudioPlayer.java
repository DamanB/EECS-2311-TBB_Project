package enamel;

public class AudioPlayer extends Player {
	
	
	public AudioPlayer(int cellNum, int buttonNum)
	{
	}

	@Override
	public void refresh() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addSkipButtonListener(int index, String param, ScenarioParser sp) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeButtonListener(int index) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addRepeatButtonListener(int index, ScenarioParser sp) {
		// TODO Auto-generated method stub
		
	}

}
